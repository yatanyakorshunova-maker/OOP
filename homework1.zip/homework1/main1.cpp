#include <iostream>
using namespace std;

int area(int a,int b) {
	return a * b;

}