#include<iostream>
#include "area.h"
using namespace std;
int main() {
	int a, b;
	cin >> a;
	cin >> b;
	int res = area(a, b);
	cout << res << endl;
	return 0;
}